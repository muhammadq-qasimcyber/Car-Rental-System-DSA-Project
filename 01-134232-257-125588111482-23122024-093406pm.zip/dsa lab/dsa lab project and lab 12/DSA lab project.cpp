#include <iostream>
#include <string>
#include <iomanip>
#include <thread>
#include <chrono>



using namespace std;

const int MAX_CARS = 5;      // Max cars per category
const int MAX_CUSTOMERS = 3; // Max customers 

// ANSI escape codes for colors
const string RESET = "\033[0m";
const string RED = "\033[31m";
const string GREEN = "\033[32m";
const string YELLOW = "\033[33m";
const string BLUE = "\033[34m";
const string MAGENTA = "\033[35m";
const string CYAN = "\033[36m";
const string WHITE = "\033[37m";

// Base class for Vehicle
class Vehicle {
protected:
    string name;
    string numberPlate;
    string color;
    double pricePerDay;
    double pricePerHour;

public:
    Vehicle(const string &n, const string &num, const string &col, double pd, double ph)
        : name(n), numberPlate(num), color(col), pricePerDay(pd), pricePerHour(ph) {}

    virtual ~Vehicle() {}

    virtual void displayDetails() const = 0; // Pure virtual function
    virtual double calculateRent(int rentType, double rentDuration) const = 0; // Pure virtual function

    string getName() const { return name; }
    string getNumberPlate() const { return numberPlate; }
    string getColor() const { return color; }
    double getPricePerDay() const { return pricePerDay; }
    double getPricePerHour() const { return pricePerHour; }
};

// Derived classes for different types of vehicles
class ElectricCar : public Vehicle {
public:
    ElectricCar(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 5000.0, 500.0) {}

    void displayDetails() const {
        cout << CYAN << "Electric Car: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class SportsCar : public Vehicle {
public:
    SportsCar(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 10000.0, 1000.0) {}

    void displayDetails() const {
        cout << YELLOW << "Sports Car: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class LuxuryCar : public Vehicle {
public:
    LuxuryCar(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 15000.0, 1500.0) {}

    void displayDetails() const {
        cout << MAGENTA << "Luxury Car: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class CustomCar : public Vehicle {
public:
    CustomCar(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 12000.0, 1200.0) {}

    void displayDetails() const {
        cout << BLUE << "Custom Car: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class Bike : public Vehicle {
public:
    Bike(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 1000.0, 100.0) {}

    void displayDetails() const {
        cout << GREEN << "Bike: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class SUV : public Vehicle {
public:
    SUV(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 8000.0, 800.0) {}

    void displayDetails() const {
        cout << RED << "SUV: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

class Truck : public Vehicle {
public:
    Truck(const string &n, const string &num, const string &col)
        : Vehicle(n, num, col, 15000.0, 1500.0) {}

    void displayDetails() const {
        cout << WHITE << "Truck: " << name << " - " << numberPlate << " - " << color << RESET << "\n";
    }

    double calculateRent(int rentType, double rentDuration) const {
        return rentType == 1 ? pricePerDay * rentDuration : pricePerHour * rentDuration;
    }
};

// Define Customer structure for the linked list
class Customer {
public:
    string name;
    string address;
    string CNIC;
    string number;
    Vehicle *rentedCar;
    Customer *next;

    Customer(const string &name, const string &address, const string &CNIC, const string &number, Vehicle *rentedCar, Customer *next = nullptr)
        : name(name), address(address), CNIC(CNIC), number(number), rentedCar(rentedCar), next(next) {}
};

// Function prototypes
void displayStartingMenu();
void displayCarCategories();
int getCarChoiceInCategory(Vehicle *vehicles[], int size);
void bookCar(Vehicle *selectedCar);
void getCustomerInfo(string &name, string &address, string &CNIC, string &number);
void calculateAndDisplayRent(Vehicle *selectedCar, int rentType, double rentDuration, const string &name, const string &address, const string &CNIC, const string &number);
bool askForAnotherBooking();
void showLoadingAnimation(const string &message);
void addCustomerToList(Customer *&head, const string &name, const string &address, const string &CNIC, const string &number, Vehicle *rentedCar);


int main() {
    // Initialize vehicles for each category
    Vehicle *electricCars[MAX_CARS] = {
        new ElectricCar("Tesla Model S", "ABC123", "White"),
        new ElectricCar("Tesla Model 3", "XYZ789", "Blue"),
        new ElectricCar("Nissan Leaf", "JKL456", "Green"),
        new ElectricCar("Chevrolet Bolt", "MNO789", "Silver"),
        new ElectricCar("BMW i3", "PQR123", "Black")};

    Vehicle *sportsCars[MAX_CARS] = {
        new SportsCar("Ferrari 488", "F1X234", "Red"),
        new SportsCar("Lamborghini Huracan", "L23456", "Yellow"),
        new SportsCar("Porsche 911", "P34567", "Blue"),
        new SportsCar("McLaren 720S", "M45678", "Orange"),
        new SportsCar("Aston Martin DB11", "A67890", "Green")};

    Vehicle *luxuryCars[MAX_CARS] = {
        new LuxuryCar("Rolls-Royce Phantom", "R12345", "Silver"),
        new LuxuryCar("Bentley Continental GT", "B23456", "Black"),
        new LuxuryCar("Maserati Quattroporte", "M45678", "Red"),
        new LuxuryCar("BMW 7 Series", "B78901", "Blue"),
        new LuxuryCar("Mercedes-Benz S-Class", "M98765", "White")};

    Vehicle *customCars[MAX_CARS] = {
        new CustomCar("Shahid Anwar G Wagon", "GHAREEBO", "Black"),
        new CustomCar("Shahid Anwar Bentley", "GHAREEBO", "Red"),
        new CustomCar("Andrew tate Bugatti ", "TOP G ", "Mad Brown"),
        new CustomCar("Shahid Anwar Ferrari Roma ", "GHAREEBO", "White"),
        new CustomCar("Shahid Anwar Mercedes", "GHAREEBO", "Black")};

    Vehicle *bikes[MAX_CARS] = {
        new Bike("Kawasaki Ninja", "K12345", "Black"),
        new Bike("Yamaha R1", "Y23456", "Blue"),
        new Bike("Honda CBR1000RR", "H34567", "Green"),
        new Bike("Suzuki GSX-R1000", "S56789", "Red"),
        new Bike("Ducati Panigale V4", "D67890", "Yellow")};

    Vehicle *suvs[MAX_CARS] = {
        new SUV("Toyota Land Cruiser", "T12345", "Silver"),
        new SUV("Ford Bronco", "F23456", "Red"),
        new SUV("Jeep Wrangler", "J34567", "Black"),
        new SUV("Land Rover Defender", "L45678", "Green"),
        new SUV("Nissan Patrol", "N56789", "Blue")};

    Vehicle *trucks[MAX_CARS] = {
        new Truck("Ford F-150", "F12345", "Silver"),
        new Truck("Chevrolet Silverado", "C23456", "Blue"),
        new Truck("Ram 1500", "R34567", "Black"),
        new Truck("GMC Sierra", "G45678", "Red"),
        new Truck("Toyota Tundra", "T56789", "Yellow")};

    Customer *customerList = nullptr;

    bool programRunning = true;
    while (programRunning) {
        displayStartingMenu();

        int menuChoice;
        cin >> menuChoice;

        switch (menuChoice) {
            case 1: {
                // Rent a car process
                bool continueBooking = true;
                while (continueBooking) {
                    displayCarCategories();
                    int carCategory;
                    cin >> carCategory;

                    Vehicle **selectedCategory = nullptr;
                    int categorySize = 0;

                    switch (carCategory) {
                        case 1: selectedCategory = electricCars; categorySize = MAX_CARS; break;
                        case 2: selectedCategory = sportsCars; categorySize = MAX_CARS; break;
                        case 3: selectedCategory = luxuryCars; categorySize = MAX_CARS; break;
                        case 4: selectedCategory = customCars; categorySize = MAX_CARS; break;
                        case 5: selectedCategory = bikes; categorySize = MAX_CARS; break;
                        case 6: selectedCategory = suvs; categorySize = MAX_CARS; break;
                        case 7: selectedCategory = trucks; categorySize = MAX_CARS; break;
                        default:
                            cout << RED << "Invalid category, please try again.\n" << RESET;
                            continue;
                    }

                    int carChoice = getCarChoiceInCategory(selectedCategory, categorySize);

                    if (carChoice < 0 || carChoice >= categorySize) {
                        cout << RED << "Invalid car choice, please try again.\n" << RESET;
                        continue;
                    }

                    Vehicle *selectedCar = selectedCategory[carChoice];

                    // Get customer information
                    string name, address, CNIC, number;
                    getCustomerInfo(name, address, CNIC, number);

                    // Show a loading animation
                    showLoadingAnimation("Booking your car...");

                    // Calculate rent and display
                    int rentType; // 1 = Day, 2 = Hour
                    double rentDuration;
                    cout << "Rent type (1 for Day, 2 for Hour): ";
                    cin >> rentType;
                    cout << "Enter rent duration: ";
                    cin >> rentDuration;
                    
                    calculateAndDisplayRent(selectedCar, rentType, rentDuration, name, address, CNIC, number);

                    // Add the customer to the list
                    addCustomerToList(customerList, name, address, CNIC, number, selectedCar);

                    // Ask if the user wants to continue booking another car
                    continueBooking = askForAnotherBooking();
                }
                break;
            }
           
            case 2:
                // Display customers at the end of the program before exit
                cout << "\n=== Customers who have rented cars ===\n";
                //displayCustomers(customerList);
                cout << "\nExiting the program... Goodbye!" << endl;
                programRunning = false;
                break;
            default:
                cout << RED << "Invalid choice. Please select again.\n" << RESET;
                break;
        }
    }

    return 0;
}

void displayStartingMenu() {
    system("cls"); // Use "clear" for Unix-like systems and cls for windows
    cout << "\n"
         << CYAN << "                                ___  __        ___     __   ___      ___            __  \n"
                    "                          |\\ | |__  |__) \\  / |__     |__) |__  |\\ |  |   /\\  |    /__` \n"
                    "                          | \\| |___ |  \\  \\/  |___    |  \\ |___ | \\|  |  /~~\\ |___ .__/ \n"
                    "                 ==============================================================================\n"
                    "                                  Welcome to Nerve Rentals - Your Car Choice!\n"
                    "                 ==============================================================================\n"
         << RESET;

    cout << GREEN << "1. Rent a Car\n"
         << RESET;
    cout << RED << "2. Exit\n"
         << RESET;
    cout << "Enter your choice: ";
}

void displayCarCategories() {
     system("cls");
    cout << GREEN << "                 ==============================================================================\n"
                     "                        __        __      __       ___  ___  __   __   __     ___  __  \n"
                     "                       /  `  /\\  |__)    /  `  /\\   |  |__  / _` /  \\ |__) | |__  /__` \n"
                     "                       \\__, /~~\\ |  \\    \\__, /~~\\  |  |___ \\__> \\__/ |  \\ | |___ .__/ \n"
                     "                 ==============================================================================\n"
         << RESET;

    cout << CYAN << "1. Electric Cars\n"
         << RESET;
    cout << RED << "2. Sports Cars\n"
         << RESET;
    cout << GREEN << "3. Luxury Cars\n"
         << RESET;
    cout << MAGENTA << "4. Custom Cars\n"
         << RESET;
    cout << BLUE << "5. Heavy Bikes\n"
         << RESET;
    cout << YELLOW << "6. SUVs\n"
         << RESET;
    cout << WHITE << "7. Trucks\n"
         << RESET;
    
    cout << "--------------------------------------\n";
    cout << "Enter the category of cars you want to view: ";
}

int getCarChoiceInCategory(Vehicle *vehicles[], int size) {
    system("cls");
    cout << BLUE <<
        "                 ========================================================================================\n"
        "                                                 __        ___          ___         __        ___  __   \n"
        "                      /\\  \\  /  /\\  | |     /\\  |__) |    |__     \\  / |__  |__| | /  ` |    |__  /__` \n"
        "                     /~~\\  \\/  /~~\\ | |___ /~~\\ |__) |___ |___     \\/  |___ |  | | \\__, |___ |___ .__/ \n"
        "                 ========================================================================================\n"
        << RESET;

    cout << "\nSelect a vehicle:\n";
    for (int i = 0; i < size; ++i) {
        cout << (i + 1) << ". ";
        vehicles[i]->displayDetails();
    }
    cout << "Enter your choice: ";
    int choice;
    cin >> choice;
    return choice - 1;
}

void getCustomerInfo(string &name, string &address, string &CNIC, string &number) {
  system("cls"); // Use "clear" for Unix-like systems

    cout << "\n" << CYAN <<
        "                 =================================================================================\n"
        "                        ___      ___  ___  __          __        __             ___  __  \n"
        "                       |__  |\\ |  |  |__  |__)    \\ / /  \\ |  | |__)    | |\\ | |__  /  \\ \n"
        "                       |___ | \\|  |  |___ |  \\     |  \\__/ \\__/ |  \\    | | \\| |    \\__/ \n"
        "                 =================================================================================\n"
        << RESET;

    cout << "Enter Your Name: ";
    cin.ignore();
    getline(cin, name);

    cout << "Enter Your Address: ";
    getline(cin, address);

    cout << "Enter Your CNIC: ";
    cin >> CNIC;

    cout << "Enter Your Contact Number: ";
    cin >> number;

    cout << "                 =================================================================================\n";
}

void calculateAndDisplayRent(Vehicle *selectedCar, int rentType, double rentDuration, const string &name, const string &address, const string &CNIC, const string &number) {
    
    double rent = selectedCar->calculateRent(rentType, rentDuration);
  system("cls");
    cout << "\n" << GREEN <<
        "                 =================================================================================\n"
        "                                __   ___      ___                      ___  __  \n"
        "                               |__) |__  |\\ |  |   /\\  |       | |\\ | |__  /  \\  \n"
        "                               |  \\ |___ | \\|  |  /~~\\ |___    | | \\| |    \\__/  \n"
        "                 =================================================================================\n"
        << RESET;

    cout << "Name: " << name << "\n";
    cout << "Address: " << address << "\n";
    cout << "CNIC: " << CNIC << "\n";
    cout << "Phone Number: " << number << "\n";
    cout << "Rented Car: " << selectedCar->getName() << "\n";
    cout << "Total Rent: " << rent << " PKR\n";
    cout << "====================================\n";
    
}

bool askForAnotherBooking() {
    cout << "Do you want to rent another car? (1 = Yes, 0 = No): ";
    int choice;
    cin >> choice;
    return choice == 1;
}

void showLoadingAnimation(const string &message) {
    cout << message << endl;
    for (int i = 0; i < 3; ++i) {
        cout << ".";
        this_thread::sleep_for(chrono::milliseconds(500));
    }
    cout << "\n";
}

void addCustomerToList(Customer *&head, const string &name, const string &address, const string &CNIC, const string &number, Vehicle *rentedCar) {
    Customer *newCustomer = new Customer(name, address, CNIC, number, rentedCar);
    newCustomer->next = head;
    head = newCustomer;
}

void displayCustomers(const Customer *head) {
    const Customer *temp = head;
    while (temp != nullptr) {
        cout << "Customer: " << temp->name << ", Rented Car: " << temp->rentedCar->getName() << "\n";
        temp = temp->next;
    }
}
bool compareByPrice(Vehicle *a, Vehicle *b)
{
    return a->getPricePerDay() < b->getPricePerDay();
}

void sortCarsByPrice(Vehicle *vehicles[], int size)
{
    sort(vehicles, vehicles + size, compareByPrice); // Using the comparator function
}



int searchCarByName(Vehicle *vehicles[], int size, const string &name)
{
    for (int i = 0; i < size; ++i)
    {
        if (vehicles[i]->getName() == name)
        {
            return i;
        }
    }
    return -1;
}
